#this Ruby code should convert a number from Fahrenheit into Celsius.
# 32 => 0
# 212 => 100
# 98.6 => 37
def ftoc(num)
  return (num - 32.0) * 5/9
end
# 0 => 32
# 20 => 68
# 37 => 98.6
# 100 => 212
def ctof(num)
  return (num * 1.8) + 32
end



            # meta_coder (Gary Miller) =)
            #gmiller052611@gmail.com